﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ChicagoInABox.Models;
using ChicagoInABox.Models.ViewModel;
using System.Web.Security;
using ChicagoInABox.Filters;

namespace ChicagoInABox.Controllers
{
    public class OrderController : Controller
    {
        private ChicagoInABoxEntities db = new ChicagoInABoxEntities();

        private ItemViewModel itemViewModel = new ItemViewModel();

        public const string CartSessionKey = "CartId";
        //
        // GET: /Order/

        public ActionResult Index()
        {
            var orders = db.Orders.Include(o => o.Address).Include(o => o.Address1).Include(o => o.User);
            return View(orders.ToList());
        }

        //
        // GET: /Order/Details/5

        public ActionResult Details(int id = 0)
        {
            Order order = db.Orders.Find(id);
            if (order == null)
            {
                return HttpNotFound();
            }
            return View(order);
        }

        //
        // GET: /Order/Create
        //[InitializeSimpleMembership]
        //[Authorize]
        public ActionResult Create()
        {
            if (TempData["model"] != null)
            {
                TempData.Keep("model");
                itemViewModel = (ItemViewModel)TempData["model"];
                //int profileID = WebMatrix.WebData.WebSecurity.GetUserId(User.Identity.Name);
                //User userInfo = db.Users.Find(profileID);
                //itemViewModel.User = userInfo;
                return View(itemViewModel);
            }
            return View(itemViewModel);
        }

        //
        // POST: /Order/Create

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(ItemViewModel model)
        {
            if (!model.AlternateShipping)
            {
                this.ViewData.ModelState.Remove("Address.Address1");
                this.ViewData.ModelState.Remove("Address.City");
                this.ViewData.ModelState.Remove("Address.State");
                this.ViewData.ModelState.Remove("Address.Zip");
                this.ViewData.ModelState.Remove("Address.Country");
            }
            if (ModelState.IsValid)
            {
                Address billingAddress = new Address() {

                    Address1 = model.Address1.Address1,
                    City = model.Address1.City,
                    State = model.Address1.State,
                    Zip = model.Address1.Zip,
                    Country = model.Address1.Country,
                };
            
                db.Addresses.Add(billingAddress);
                Address shippingDetails = new Address();
                if (model.AlternateShipping)
                {
                    Address shippingAddress = new Address()
                    {
                        Address1 = model.Address.Address1,
                        City = model.Address.City,
                        State = model.Address.State,
                        Zip = model.Address.Zip,
                        Country = model.Address.Country,
                    };
                    shippingDetails = shippingAddress;
                    db.Addresses.Add(shippingDetails);
                }
                else
                {
                    shippingDetails = billingAddress;
                }
                db.SaveChanges();

                Order order = new Order()
                {
                    BillToID = billingAddress.AddressID,
                    ShipToID = shippingDetails.AddressID,
                    UserID = model.User.UserID,
                    OrderQty = Convert.ToInt32(model.OrderQty),
                    OrderSize = Convert.ToInt32(model.OrderSize),
                    OrderDate = DateTime.Now,
                    Notes = model.Notes
                };
                    db.Orders.Add(order);
                    db.SaveChanges();                   

                    var AssemblingBox = db.Carts.Where(c => c.CartId == model.CartId);

                    foreach (Cart item in AssemblingBox)
                    {
                        item.CartId = model.User.UserID.ToString();
                        OrderDetail orderDetail = new OrderDetail()
                        {
                            OrderID = order.OrderID,
                            ItemID = item.ItemID,
                            Quantity = item.OrderQty,
                            LastName = item.FirstName,
                            FirstName = item.LastName
                        };
                        db.OrderDetails.Add(orderDetail);
                    }
                    PaymentDetail payment = new PaymentDetail()
                    {
                        PaymentMethod = model.PaymentDetails.PaymentMethod,
                        CardNumber = model.PaymentDetails.CardNumber, 
                        SecurityCode = model.PaymentDetails.SecurityCode,
                        PaymentAmt = model.OrderTotal,
                        ExpirationDate = model.PaymentDetails.ExpirationDate,
                        OrderID = order.OrderID,
                    };
                    db.PaymentDetails.Add(payment);
                    db.SaveChanges();
                    TempData["model"] = model;  
                    
                    return RedirectToAction("OrderConfirmation", "Order");
                }

            return View(model);
        }

        //
        //GET: /Order/OrderConfirmation
        public ActionResult OrderConfirmation()
        {
            if (TempData["model"] != null)
            {
                TempData.Keep("model");
                itemViewModel = (ItemViewModel)TempData["model"];
                return View(itemViewModel);
            }

            return View();
        }

        //
        // GET: /Order/Edit/5

        public ActionResult Edit(int id = 0)
        {
            Order order = db.Orders.Find(id);
            if (order == null)
            {
                return HttpNotFound();
            }
            ViewBag.BillToID = new SelectList(db.Addresses, "AddressID", "Address1", order.BillToID);
            ViewBag.ShipToID = new SelectList(db.Addresses, "AddressID", "Address1", order.ShipToID);
            ViewBag.UserID = new SelectList(db.Users, "UserID", "FirstName", order.UserID);
            return View(order);
        }

        //
        // POST: /Order/Edit/5

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Order order)
        {
            if (ModelState.IsValid)
            {
                db.Entry(order).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.BillToID = new SelectList(db.Addresses, "AddressID", "Address1", order.BillToID);
            ViewBag.ShipToID = new SelectList(db.Addresses, "AddressID", "Address1", order.ShipToID);
            ViewBag.UserID = new SelectList(db.Users, "UserID", "FirstName", order.UserID);
            return View(order);
        }

        //
        // GET: /Order/Delete/5

        public ActionResult Delete(int id = 0)
        {
            Order order = db.Orders.Find(id);
            if (order == null)
            {
                return HttpNotFound();
            }
            return View(order);
        }

        //
        // POST: /Order/Delete/5

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Order order = db.Orders.Find(id);
            db.Orders.Remove(order);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}