﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ChicagoInABox.Models;

namespace ChicagoInABox.Controllers
{
    public class PaymentDetailController : Controller
    {
        private ChicagoInABoxEntities db = new ChicagoInABoxEntities();

        //
        // GET: /PaymentDetail/

        public ActionResult Index()
        {
            var paymentdetails = db.PaymentDetails.Include(p => p.Order);
            return View(paymentdetails.ToList());
        }

        //
        // GET: /PaymentDetail/Details/5

        public ActionResult Details(int id = 0)
        {
            PaymentDetail paymentdetail = db.PaymentDetails.Find(id);
            if (paymentdetail == null)
            {
                return HttpNotFound();
            }
            return View(paymentdetail);
        }

        //
        // GET: /PaymentDetail/Create

        public ActionResult Create()
        {
            ViewBag.OrderID = new SelectList(db.Orders, "OrderID", "OrderID");
            return View();
        }

        //
        // POST: /PaymentDetail/Create

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(PaymentDetail paymentdetail)
        {
            if (ModelState.IsValid)
            {
                db.PaymentDetails.Add(paymentdetail);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.OrderID = new SelectList(db.Orders, "OrderID", "OrderID", paymentdetail.OrderID);
            return View(paymentdetail);
        }

        //
        // GET: /PaymentDetail/Edit/5

        public ActionResult Edit(int id = 0)
        {
            PaymentDetail paymentdetail = db.PaymentDetails.Find(id);
            if (paymentdetail == null)
            {
                return HttpNotFound();
            }
            ViewBag.OrderID = new SelectList(db.Orders, "OrderID", "OrderID", paymentdetail.OrderID);
            return View(paymentdetail);
        }

        //
        // POST: /PaymentDetail/Edit/5

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(PaymentDetail paymentdetail)
        {
            if (ModelState.IsValid)
            {
                db.Entry(paymentdetail).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.OrderID = new SelectList(db.Orders, "OrderID", "OrderID", paymentdetail.OrderID);
            return View(paymentdetail);
        }

        //
        // GET: /PaymentDetail/Delete/5

        public ActionResult Delete(int id = 0)
        {
            PaymentDetail paymentdetail = db.PaymentDetails.Find(id);
            if (paymentdetail == null)
            {
                return HttpNotFound();
            }
            return View(paymentdetail);
        }

        //
        // POST: /PaymentDetail/Delete/5

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            PaymentDetail paymentdetail = db.PaymentDetails.Find(id);
            db.PaymentDetails.Remove(paymentdetail);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}